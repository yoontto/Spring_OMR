package test;

public class TestVO {
	private String test_name;
	private int test_num;
	private String test_problem;
	private int test_answer;
	private String test_choice1;
	private String test_choice2;
	private String test_choice3;
	private String test_choice4;
	
	
	public String getTest_name() {
		return test_name;
	}
	public void setTest_name(String test_name) {
		this.test_name = test_name;
	}
	public int getTest_num() {
		return test_num;
	}
	public void setTest_num(int test_num) {
		this.test_num = test_num;
	}
	public String getTest_problem() {
		return test_problem;
	}
	public void setTest_problem(String test_problem) {
		this.test_problem = test_problem;
	}
	public int getTest_answer() {
		return test_answer;
	}
	public void setTest_answer(int test_answer) {
		this.test_answer = test_answer;
	}
	public String getTest_choice1() {
		return test_choice1;
	}
	public void setTest_choice1(String test_choice1) {
		this.test_choice1 = test_choice1;
	}
	public String getTest_choice2() {
		return test_choice2;
	}
	public void setTest_choice2(String test_choice2) {
		this.test_choice2 = test_choice2;
	}
	public String getTest_choice3() {
		return test_choice3;
	}
	public void setTest_choice3(String test_choice3) {
		this.test_choice3 = test_choice3;
	}
	public String getTest_choice4() {
		return test_choice4;
	}
	public void setTest_choice4(String test_choice4) {
		this.test_choice4 = test_choice4;
	}
	
	
}
