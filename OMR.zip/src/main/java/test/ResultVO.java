package test;

public class ResultVO {
	int 	candidate_num       ;
	String  candidate_test_name ;
	int		candidate_get_right ;
	
	
	public int getCandidate_num() {
		return candidate_num;
	}
	public void setCandidate_num(int candidate_num) {
		this.candidate_num = candidate_num;
	}
	public String getCandidate_test_name() {
		return candidate_test_name;
	}
	public void setCandidate_test_name(String candidate_test_name) {
		this.candidate_test_name = candidate_test_name;
	}
	public int getCandidate_get_right() {
		return candidate_get_right;
	}
	public void setCandidate_get_right(int candidate_get_right) {
		this.candidate_get_right = candidate_get_right;
	}
	
	
	
	
	
}//class
